// ==== State & Utils ====
const state = {
  me: null,
  users: [],
  posts: [],
  videos: [],
  promos: [],
  chats: {}
};

const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));
const uid = () => 'id_' + Math.random().toString(36).slice(2,9) + Date.now().toString(36);

function save() { localStorage.setItem('lc_state', JSON.stringify(state)); }
function load() {
  const data = JSON.parse(localStorage.getItem('lc_state') || 'null');
  if (data) Object.assign(state, data);
  else seedDemo();
}
function seedDemo() {
  // create 3 demo users
  state.users = [
    { uid:'u_alex', name:'Alex', email:'alex@gmail.com', photo:'' },
    { uid:'u_bola', name:'Bola', email:'bola@gmail.com', photo:'' },
    { uid:'u_chi',  name:'Chioma', email:'chioma@gmail.com', photo:'' }
  ];
  // a few sample text/image/link posts
  const p1 = { id:uid(), uid:'u_bola', kind:'text', text:'New week, new colors!', ts:Date.now()-3600000, likes:0, comments:[], link:'' };
  const p2 = { id:uid(), uid:'u_chi',  kind:'image', url:'https://source.unsplash.com/random/800x450', text:'Lagos vibes', ts:Date.now()-1800000, likes:3, comments:[], link:'' };
  const p3 = { id:uid(), uid:'u_alex', kind:'link', url:'https://developer.mozilla.org', text:'Great docs!', ts:Date.now()-600000, likes:2, comments:[], link:'' };
  [p1,p2,p3].forEach(addLink);
  state.posts = [p1,p2,p3];
  state.videos = [];
  state.promos = [];
  state.chats['group:general'] = [
    { id:uid(), from:'u_alex', text:'Welcome to #general!', ts:Date.now()-7200000 },
    { id:uid(), from:'u_bola', text:'Hi everyone!', ts:Date.now()-7000000 }
  ];
}
function addLink(item) {
  item.link = location.origin + location.pathname + '#/post/' + item.id;
}
function formatTime(ts) {
  return new Date(ts).toLocaleString();
}
function getUser(uid) {
  return state.users.find(u=>u.uid===uid) || { uid:'guest', name:'Guest', photo:'' };
}
function ensureAvatar(imgEl, uid) {
  const user = getUser(uid);
  if (user.photo) imgEl.src = user.photo;
  else imgEl.src = `data:image/svg+xml;utf8,${encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80">
       <rect width="100%" height="100%" rx="14" fill="#1c2230"/>
       <text x="50%" y="55%" text-anchor="middle" fill="#9fb0c6" font-size="32">👤</text>
     </svg>`
  )}`;
}

// ==== Auth (Mock Google) ====
$('#signInBtn').onclick = ()=>{
  const email = prompt('Enter your Gmail:');
  if (!email || !/@gmail\.com$/i.test(email)) return alert('Use a valid @gmail.com');
  const name = prompt('Display name:') || email.split('@')[0];
  state.me = { uid:'u_'+email.replace(/[^a-z0-9]/gi,''), name, email, photo:'' };
  state.users.push(state.me);
  save(); reflectAuth();
};
$('#signOutBtn').onclick = ()=>{
  state.me = null; save(); reflectAuth();
};
function reflectAuth(){
  if(state.me){
    $('#authStatus').textContent = `${state.me.name} — signed in`;
    $('#signInBtn').classList.add('hide');
    $('#signOutBtn').classList.remove('hide');
  } else {
    $('#authStatus').textContent = 'Guest — view only';
    $('#signInBtn').classList.remove('hide');
    $('#signOutBtn').classList.add('hide');
  }
  $('#postHint').textContent    = state.me ? 'You can post now' : 'Posting as guest is disabled';
  $('#videoGuard').textContent  = state.me ? 'Ready to upload' : 'Sign in required to upload';
  $('#chatHint').textContent    = state.me ? 'Connected' : 'Sign in to send';
  $('#createPostBtn').disabled  = !state.me;
  $('#uploadVideoBtn').disabled = !state.me;
  $('#sendMsgBtn').disabled     = !state.me;
  ensureAvatar($('#composerAvatar'), state.me?.uid);
  ensureAvatar($('#uploaderAvatar'), state.me?.uid);
  ensureAvatar($('#profileAvatar'), state.me?.uid);
  $('#profileName').textContent  = state.me?.name || 'Guest';
  $('#profileEmail').textContent = state.me?.email || 'Not signed in';
  renderAll();
}

// ==== Navigation ====
$$('.nav-btn').forEach(btn=>{
  btn.onclick = ()=>{
    const tab = btn.dataset.nav;
    state.tab = tab;
    $$('.nav-btn').forEach(b=>b.classList.toggle('active', b===btn));
    $$('.page').forEach(p=>p.classList.remove('active'));
    $(`#page-${tab}`).classList.add('active');
    if(tab==='home') maybeDeep();
    renderAll();
  };
});

// ==== Home Composer ====
let chosenFile = null;
$$('.tabs .tab[data-kind]').forEach(tab=>{
  tab.onclick = ()=>{
    const kind = tab.dataset.kind;
    state.postKind = kind;
    $$('.tabs .tab').forEach(t=>t.classList.toggle('active', t===tab));
    $('#postText').placeholder = {
      text:'Share something vibrant...',
      image:'Describe your image...',
      video:'Describe your video...',
      link:'Enter a link + note...'
    }[kind];
    $('#postFile').classList.toggle('hide', kind!=='image' && kind!=='video');
    $('#chooseFileBtn').classList.toggle('hide', kind!=='image' && kind!=='video');
    $('#postLink').classList.toggle('hide', kind!=='link');
    $('#filePreview').classList.add('hide');
    chosenFile = null;
    $('#postFile').value = '';
    $('#postLink').value = '';
  };
});
$('#chooseFileBtn').onclick = ()=>$('#postFile').click();
$('#postFile').onchange = e=>{
  chosenFile = e.target.files[0] || null;
  const prev = $('#filePreview');
  prev.classList.toggle('hide', !chosenFile);
  if(chosenFile){
    const url = URL.createObjectURL(chosenFile);
    prev.innerHTML = chosenFile.type.startsWith('image/') ?
      `<img src="${url}">` :
      `<video src="${url}" controls></video>`;
  }
};

$('#createPostBtn').onclick = ()=>{
  if(!state.me) return alert('Sign in first');
  const kind = state.postKind;
  const text = $('#postText').value.trim();
  const link = $('#postLink').value.trim();
  const p = { id:uid(), uid:state.me.uid, kind, text, ts:Date.now(), likes:0, comments:[] };
  if(kind==='link'){
    if(!/^https?:\/\//.test(link)) return alert('Invalid URL');
    p.url = link;
  }
  if((kind==='image'||kind==='video') && chosenFile){
    p.url = URL.createObjectURL(chosenFile);
  }
  addLink(p);
  state.posts.unshift(p);
  $('#postText').value = '';
  $('#postLink').value = '';
  chosenFile = null;
  $('#filePreview').classList.add('hide');
  $('#filePreview').innerHTML = '';
  save(); renderFeed();
};

// Pull to refresh (touch)
(function(){
  const container = $('#page-home');
  const indicator = $('.ptr .indicator');
  let startY=0, pulling=false, ready=false;
  container.addEventListener('touchstart', e=>{
    if(container.scrollTop>0) return;
    pulling=true; startY=e.touches[0].clientY;
    document.querySelector('.ptr').classList.add('active');
  }, {passive:true});
  container.addEventListener('touchmove', e=>{
    if(!pulling) return;
    const dy = e.touches[0].clientY - startY;
    if(dy>10){
      indicator.style.top = (-36 + Math.min(30, dy/4))+'px';
      ready = dy>90;
      document.querySelector('.ptr').classList.toggle('ready', ready);
    }
  }, {passive:true});
  ['touchend','touchcancel'].forEach(ev=>{
    container.addEventListener(ev, ()=>{
      if(!pulling) return;
      pulling=false;
      document.querySelector('.ptr').classList.remove('active','ready');
      indicator.style.top='-36px';
      if(ready) {
        const demo = { id:uid(), uid:'u_bola', kind:'text', text:'Refreshed ✨ '+new Date().toLocaleTimeString(), ts:Date.now(), likes:0, comments:[] };
        addLink(demo);
        state.posts.unshift(demo);
        save(); renderFeed();
      }
    });
  });
})();

// ==== Video Upload ====
$('#uploadVideoBtn').onclick = ()=>{
  if(!state.me) return alert('Sign in first');
  const f = $('#videoFile').files[0];
  if(!f||!f.type.startsWith('video/')) return alert('Choose a video');
  const url = URL.createObjectURL(f);
  const text = $('#videoDesc').value.trim();
  const v = { id:uid(), uid:state.me.uid, url, text, ts:Date.now(), likes:0, comments:[] };
  addLink(v);
  state.videos.unshift(v);
  // mirror into feed
  state.posts.unshift({ ...v, kind:'video', link:v.link });
  $('#videoFile').value=''; $('#videoDesc').value='';
  save(); renderVideoFeed(); renderFeed(); renderProfileFeed();
};

// ==== Chat (BroadcastChannel) ====
const bc = window.BroadcastChannel ? new BroadcastChannel('lc_chat') : null;
if(bc) bc.onmessage = e => { if(e.data?.type==='chat') ingest(e.data.msg); };

function threadPrivate(a,b){ return 'private:' + [a,b].sort().join('_'); }
function threadGroup(name){ return 'group:' + name; }

let currentThread = null;
$$('.tabs .tab[data-chat-tab]').forEach(tab=>{
  tab.onclick = ()=>{
    state.chatTab = tab.dataset.chatTab;
    $$('.tabs .tab').forEach(t=>t.classList.toggle('active', t===tab));
    populateChatList();
  };
});

function populateChatList(){
  const list = $('#chatList');
  list.innerHTML = '';
  if(state.chatTab==='private'){
    state.users.filter(u=>u.uid!==state.me?.uid).forEach(u=>{
      const el = document.createElement('div');
      el.className='chat-item';
      el.innerHTML = `<div class="split"><img class="avatar"><div><div>${u.name}</div></div></div>`;
      el.onclick = ()=>{
        currentThread = threadPrivate(state.me.uid, u.uid);
        openThread(u.name);
      };
      list.appendChild(el);
    });
  } else {
    ['general','music','movies','tech','lagos'].forEach(g=>{
      const el = document.createElement('div');
      el.className='chat-item';
      el.innerHTML = `<div class="split"><div class="tag">#${g}</div><div>Group chat</div></div>`;
      el.onclick = ()=>{
        currentThread = threadGroup(g);
        openThread('#'+g);
      };
      list.appendChild(el);
    });
  }
}

function openThread(name){
  $('#messages').innerHTML = '';
  $('#messages').insertAdjacentHTML('beforebegin', `<div class="muted" style="padding:8px;">Talking in ${name}</div>`);
  renderMessages();
}

$('#sendMsgBtn').onclick = sendMsg;
$('#chatInput').addEventListener('keydown', e=>{ if(e.key==='Enter') sendMsg(); });

function sendMsg(){
  if(!state.me) return alert('Sign in first');
  const txt = $('#chatInput').value.trim();
  if(!txt) return;
  const msg = { id:uid(), thread:currentThread||threadGroup('general'), from:state.me.uid, text:txt, ts:Date.now() };
  state.chats[msg.thread] = state.chats[msg.thread]||[];
  state.chats[msg.thread].push(msg);
  save();
  ingest(msg);
  if(bc) bc.postMessage({ type:'chat', msg });
  $('#chatInput').value='';
}

function ingest(msg){
  if(!state.chats[msg.thread]) state.chats[msg.thread]=[];
  if(!state.chats[msg.thread].some(m=>m.id===msg.id)) {
    state.chats[msg.thread].push(msg);
    save();
  }
  renderMessages();
}

function renderMessages(){
  const msgs = state.chats[currentThread]||[];
  const box = $('#messages');
  box.innerHTML = '';
  msgs.sort((a,b)=>a.ts-b.ts).forEach(m=>{
    const u = getUser(m.from);
    const div = document.createElement('div');
    const mine = state.me&&m.from===state.me.uid;
    div.className = 'msg ' + (mine?'me':'them');
    div.innerHTML = `<strong>${u.name}</strong>: ${m.text}`;
    box.appendChild(div);
  });
  box.scrollTop = box.scrollHeight;
}

// ==== Promotion ====
$('#promoPublish').onclick = ()=>{
  const color = $('#promoColor').value;
  const text = $('#promoText').value.trim();
  if(!text) return;
  state.promos.unshift({ id:uid(), color, text, ts:Date.now() });
  $('#promoText').value='';
  save(); renderPromos();
};
function renderPromos(){
  const feed = $('#promoFeed'); feed.innerHTML='';
  state.promos.forEach(pr=>{
    const el = document.createElement('div');
    el.className='card';
    el.innerHTML = `
      <div class="card-body">
        <div class="split"><span class="tag" style="color:var(--${pr.color});border-color:var(--${pr.color})">● ${pr.color}</span>
        <span class="muted">${formatTime(pr.ts)}</span></div>
        <p>${pr.text}</p>
      </div>`;
    feed.appendChild(el);
  });
}

// ==== Profile ====
$('#profilePhotoInput').onchange = e=>{
  const f = e.target.files[0];
  if(!f||!state.me) return;
  state.me.photo = URL.createObjectURL(f);
  save(); reflectAuth();
};

function renderProfileFeed(){
  const feed = $('#profileFeed');
  feed.innerHTML = '';
  if(!state.me) {
    feed.innerHTML = `<p class="muted">Sign in to see your posts.</p>`;
    return;
  }
  const mine = state.posts.filter(p=>p.uid===state.me.uid).sort((a,b)=>b.ts-a.ts);
  mine.forEach(p=>{
    const el = document.createElement('div');
    el.className='card';
    el.innerHTML = `
      <div class="card-header split">
        <img class="avatar"><div><strong>${state.me.name}</strong><div class="meta">${formatTime(p.ts)}</div></div>
        <div class="right tag link"><a href="${p.link}"># Link</a></div>
      </div>
      <div class="card-body">
        ${p.text?`<p>${p.text}</p>`:''}
        ${p.kind==='image'?`<div class="media"><img src="${p.url}"></div>`:''}
        ${p.kind==='video'?`<div class="media"><video src="${p.url}" controls></video></div>`:''}
        ${p.kind==='link'?`<p><a href="${p.url}" target="_blank">${p.url}</a></p>`:''}
      </div>`;
    feed.appendChild(el);
  });
}

// ==== Deep link highlight ====
function maybeDeep(){
  const h = location.hash;
  if(!h.startsWith('#/post/')) return;
  const id = h.split('/')[2];
  renderFeed();
  const card = [...$('#feed').children].find(c=>c.innerHTML.includes(`#/post/${id}`));
  if(card){
    card.style.boxShadow='0 0 0 3px #ffd666';
    card.scrollIntoView({behavior:'smooth', block:'center'});
    setTimeout(()=>card.style.boxShadow='', 2500);
  }
}
window.addEventListener('hashchange', ()=>{
  if(state.tab!=='home'){
    state.tab='home';
    $$('.nav-btn').forEach(b=>b.classList.toggle('active', b.dataset.nav==='home'));
    $$('.page').forEach(p=>p.classList.remove('active'));
    $('#page-home').classList.add('active');
  }
  maybeDeep();
});

// ==== Rendering all ====
function renderFeed() {
  const feed = $('#feed');
  feed.innerHTML = '';
  const q = $('#searchUsers').value.trim().toLowerCase();
  state.posts
    .filter(p=>!q||getUser(p.uid).name.toLowerCase().includes(q))
    .sort((a,b)=>b.ts-a.ts)
    .forEach(p=>{
      const u = getUser(p.uid);
      const el = document.createElement('div');
      el.className = 'card';
      el.innerHTML = `
        <div class="card-header split">
          <img class="avatar"><div><strong>${u.name}</strong><div class="meta">${formatTime(p.ts)}</div></div>
          <div class="right tag link"><a href="${p.link}"># Link</a></div>
        </div>
        <div class="card-body">
          ${p.text?`<p>${p.text}</p>`:''}
          ${p.kind==='image'?`<div class="media"><img src="${p.url}"></div>`:''}
          ${p.kind==='video'?`<div class="media"><video src="${p.url}" controls></video></div>`:''}
          ${p.kind==='link'?`<p><a href="${p.url}" target="_blank">${p.url}</a></p>`:''}
        </div>
        <div class="card-footer actions">
          <button class="stat like">💚 ${p.likes}</button>
          <button class="stat comment">💬 ${p.comments.length}</button>
          <button class="stat share">🔗 Share</button>
        </div>`;
      feed.appendChild(el);
    });
}
function renderVideoFeed(){ renderFeed(); } // we mirror videos into posts
function renderAll() {
  renderFeed();
  renderVideoFeed();
  populateChatList();
  renderPromos();
  renderProfileFeed();
  renderMessages();
}

load();
reflectAuth();
state.tab = 'home';
renderAll();
